class MyRoutes{
  static String loginRoute = "/login";
  static String homeRoute = "/home";
}